﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ProyectoFG5.Data;
using ProyectoFG5.Models;

namespace ProyectoFG5.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AnfitrionesController : ControllerBase
    {
        private readonly BDConexion _context;

        public AnfitrionesController(BDConexion context)
        {
            _context = context;
        }

        // GET: api/Anfitriones
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Anfitrion>>> Getanfitriones()
        {
            return await _context.anfitriones.ToListAsync();
        }

        // GET: api/Anfitriones/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Anfitrion>> GetAnfitrion(int id)
        {
            var anfitrion = await _context.anfitriones.FindAsync(id);

            if (anfitrion == null)
            {
                return NotFound();
            }

            return anfitrion;
        }

        // PUT: api/Anfitriones/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutAnfitrion(int id, Anfitrion anfitrion)
        {
            if (id != anfitrion.IdAnfitrion)
            {
                return BadRequest();
            }

            _context.Entry(anfitrion).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!AnfitrionExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Anfitriones
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<Anfitrion>> PostAnfitrion(Anfitrion anfitrion)
        {
            var IdAnfitrion = await _context.anfitriones.FindAsync(anfitrion.IdAnfitrion);
            if (IdAnfitrion != null)
            {
                return BadRequest("El anfitrion existe");
            }
            _context.anfitriones.Add(anfitrion);
            await _context.SaveChangesAsync();
            return Ok("Anfitrion registrado correctamente");
        }

        // DELETE: api/Anfitriones/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteAnfitrion(int id)
        {
            var anfitrion = await _context.anfitriones.FindAsync(id);
            if (anfitrion == null)
            {
                return NotFound();
            }

            _context.anfitriones.Remove(anfitrion);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool AnfitrionExists(int id)
        {
            return _context.anfitriones.Any(e => e.IdAnfitrion == id);
        }
    }
}
