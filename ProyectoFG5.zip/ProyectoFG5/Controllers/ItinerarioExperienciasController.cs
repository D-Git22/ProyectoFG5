﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ProyectoFG5.Data;
using ProyectoFG5.Models;

namespace ProyectoFG5.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ItinerarioExperienciasController : ControllerBase
    {
        private readonly BDConexion _context;

        public ItinerarioExperienciasController(BDConexion context)
        {
            _context = context;
        }

        // GET: api/ItinerarioExperiencias
        [HttpGet]
        public async Task<ActionResult<IEnumerable<ItinerarioExperiencia>>> GetitinerarioExperiencias()
        {
            return await _context.itinerarioExperiencias.ToListAsync();
        }

        // GET: api/ItinerarioExperiencias/5
        [HttpGet("{id}")]
        public async Task<ActionResult<ItinerarioExperiencia>> GetItinerarioExperiencia(int id)
        {
            var itinerarioExperiencia = await _context.itinerarioExperiencias.FindAsync(id);

            if (itinerarioExperiencia == null)
            {
                return NotFound();
            }

            return itinerarioExperiencia;
        }

        // PUT: api/ItinerarioExperiencias/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutItinerarioExperiencia(int id, ItinerarioExperiencia itinerarioExperiencia)
        {
            if (id != itinerarioExperiencia.IdItinerarioExperiencia)
            {
                return BadRequest();
            }

            _context.Entry(itinerarioExperiencia).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ItinerarioExperienciaExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/ItinerarioExperiencias
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<ItinerarioExperiencia>> PostItinerarioExperiencia(ItinerarioExperiencia itinerarioExperiencia)
        {
            var IdItinerarioExperiencia = await _context.itinerarioExperiencias.FindAsync(itinerarioExperiencia.IdItinerarioExperiencia);
            if (IdItinerarioExperiencia != null)
            {
                return BadRequest("El itinerario experiencia no existe existe");
            }
            _context.itinerarioExperiencias.Add(itinerarioExperiencia);
            await _context.SaveChangesAsync();
            return Ok("Itinerario experiencia registrada correctamente");
        }

        // DELETE: api/ItinerarioExperiencias/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteItinerarioExperiencia(int id)
        {
            var itinerarioExperiencia = await _context.itinerarioExperiencias.FindAsync(id);
            if (itinerarioExperiencia == null)
            {
                return NotFound();
            }

            _context.itinerarioExperiencias.Remove(itinerarioExperiencia);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool ItinerarioExperienciaExists(int id)
        {
            return _context.itinerarioExperiencias.Any(e => e.IdItinerarioExperiencia == id);
        }
    }
}
