﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ProyectoFG5.Data;
using ProyectoFG5.Models;

namespace ProyectoFG5.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ItinerariosController : ControllerBase
    {
        private readonly BDConexion _context;

        public ItinerariosController(BDConexion context)
        {
            _context = context;
        }

        // GET: api/Itinerarios
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Itinerario>>> Getitinerarios()
        {
            return await _context.itinerarios.ToListAsync();
        }

        // GET: api/Itinerarios/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Itinerario>> GetItinerario(int id)
        {
            var itinerario = await _context.itinerarios.FindAsync(id);

            if (itinerario == null)
            {
                return NotFound();
            }

            return itinerario;
        }

        // PUT: api/Itinerarios/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutItinerario(int id, Itinerario itinerario)
        {
            if (id != itinerario.IdItinerario)
            {
                return BadRequest();
            }

            _context.Entry(itinerario).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ItinerarioExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Itinerarios
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<Itinerario>> PostItinerario(Itinerario itinerario)
        {
            var IdItinerario = await _context.itinerarios.FindAsync(itinerario.IdItinerario);
            if (IdItinerario != null)
            {
                return BadRequest("El itinerario existe");
            }
            _context.itinerarios.Add(itinerario);
            await _context.SaveChangesAsync();
            return Ok("Itinerario registrado correctamente");
        }

        // DELETE: api/Itinerarios/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteItinerario(int id)
        {
            var itinerario = await _context.itinerarios.FindAsync(id);
            if (itinerario == null)
            {
                return NotFound();
            }

            _context.itinerarios.Remove(itinerario);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool ItinerarioExists(int id)
        {
            return _context.itinerarios.Any(e => e.IdItinerario == id);
        }
    }
}
