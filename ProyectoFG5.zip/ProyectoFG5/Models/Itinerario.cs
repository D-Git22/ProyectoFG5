﻿using ProyectoFG5.Models;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ProyectoFG5.Models
{
    //Itinerarios (es una guía EN orden recomendado de experiencias, sin que obligue a clientes a
    //reservar experiencias, parecido a una proyeccion de materias indicando cual cursar primero o 
    //después.)
    public class Itinerario
    {
        [Key]
        public int IdItinerario { get; set; }

        [Required(ErrorMessage = "El nombre completo es obligatorio")]
        [StringLength(50, MinimumLength = 3)]
        public string? Nombre { get; set; }

    }
}