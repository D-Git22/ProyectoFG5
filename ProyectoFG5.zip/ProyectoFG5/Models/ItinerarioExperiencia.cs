﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ProyectoFG5.Models
{
    public class ItinerarioExperiencia
    {
        [Key]
        public int IdItinerarioExperiencia { get; set; }

        public int IdItinerario { get; set; }
        [ForeignKey(nameof(IdItinerario))]
        public Itinerario? itinerario { get; set; }

        public int IdExperiencia { get; set; }
        [ForeignKey(nameof(IdExperiencia))]
        public Experiencia? experiencia { get; set; }

    }
}

