﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ProyectoFG5.Models
{
    public class Reseña
    {
        [Key]
        public int IdReseña { get; set; }

        public int IdCliente { get; set; }
        [ForeignKey(nameof(IdCliente))]
        public Cliente? cliente { get; set; }

        public int IdExperiencia { get; set; }
        [ForeignKey(nameof(IdExperiencia))]
        public Experiencia? experiencia { get; set; }

        [Required]
        [Range(1, 5)]
        public int Calificacion { get; set; }

        [StringLength(50, MinimumLength = 3)]
        public string? Comentario { get; set; }

        [DataType(DataType.Date)]
        public DateTime? Fecha { get; set; }
    }
}