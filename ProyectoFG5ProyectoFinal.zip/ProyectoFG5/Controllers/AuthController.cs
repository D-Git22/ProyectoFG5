﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using ProyectoFG5.Data;
using ProyectoFG5.Models;
using System.ComponentModel.DataAnnotations;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.EntityFrameworkCore;

namespace ProyectoFG5.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly BDConexion bDConexion;
        private readonly IConfiguration _configuration;
        public AuthController(BDConexion bDConexion, IConfiguration configuration)
        {
            this.bDConexion = bDConexion;
            _configuration = configuration;
        }
        //regustro de usuario 
        [HttpPost("register")]
        public async Task<IActionResult> Register(RegisterRequest request)
        {
            if (!ModelState.IsValid)
                return BadRequest("No hay datos");
            //veruficar si ya existe el email 
            if (await bDConexion.usuarios.AnyAsync(u => u.Email == request.Email))
                return BadRequest(new { mensaje = "El email ya esta registrado " });
            // crear usuarioo con contraseña hasheada
            var usuario = new Usuario
            {
                Email = request.Email,
                Password = BCrypt.Net.BCrypt.HashPassword(request.Password)
            };
            bDConexion.usuarios.Add(usuario);
            await bDConexion.SaveChangesAsync();
            return Ok("Usuario registrado correctamente");

        }
        [HttpPost("login")]
        public async Task<IActionResult> Login(LoginRequest request)
        {
            if (!ModelState.IsValid)
                return BadRequest("Datos  vacios ");

            var usuario = await bDConexion.usuarios.FirstOrDefaultAsync(u => u.Email == request.Email);
            if (usuario == null || !BCrypt.Net.BCrypt.Verify(request.Password, usuario.Password))
            {
                return Unauthorized(new { mensaje = "Credenciales invalidas" });
            }

            var token = GenerateJwtToken(usuario);

            //  DEVOLVER JSON en vez de solo texto
            return Ok(new { mensaje = "Usuario logueado", token });

        }
        private string GenerateJwtToken(Usuario usuario)
        {
            var claims = new[]
            {
                new Claim(ClaimTypes.NameIdentifier, usuario.Id.ToString()),
                new Claim(ClaimTypes.Email, usuario.Email),
                new Claim(ClaimTypes.Role, "User")
            };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]));

            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                issuer: _configuration["Jwt: Issuer"],
                audience: _configuration["Jwt:Audience"],
                claims: claims,
                expires: DateTime.Now.AddHours(2),
                signingCredentials: creds

            );

            return new JwtSecurityTokenHandler().WriteToken(token);

        }
    }
    //datos
    public class RegisterRequest
    {
        [Required, EmailAddress]
        public string? Email { get; set; }
        [Required, MinLength(6)]
        public string? Password { get; set; }

    }
    // vaidar los datos de la base de datos 
    public class LoginRequest
    {
        [Required, EmailAddress]
        public string? Email { get; set; }
        [Required]
        public string? Password { get; set; }
    }
}
