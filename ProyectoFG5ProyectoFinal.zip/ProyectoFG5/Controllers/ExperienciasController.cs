﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ProyectoFG5.Data;
using ProyectoFG5.Models;

namespace ProyectoFG5.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ExperienciasController : ControllerBase
    {
        private readonly BDConexion _context;

        public ExperienciasController(BDConexion context)
        {
            _context = context;
        }

        // GET: api/Experiencias
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Experiencia>>> Getexperiencias()
        {
            return await _context.experiencias.ToListAsync();
        }

        // GET: api/Experiencias/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Experiencia>> GetExperiencia(int id)
        {
            var experiencia = await _context.experiencias.FindAsync(id);

            if (experiencia == null)
            {
                return NotFound();
            }

            return experiencia;
        }

        // PUT: api/Experiencias/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutExperiencia(int id, Experiencia experiencia)
        {
            if (id != experiencia.IdExperiencia)
            {
                return BadRequest();
            }

            _context.Entry(experiencia).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ExperienciaExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Experiencias
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<Experiencia>> PostExperiencia(Experiencia experiencia)
        {
            //verificar si existe el anfitrion 
            var IdAnfitrion = await _context.anfitriones.FindAsync(experiencia.IdAnfitrion);
            if (IdAnfitrion == null)
            {
                return BadRequest("El proveedor no existe");
            }
            //Verificar si existe la categoria
            var IdCategoria = await _context.categorias.FindAsync(experiencia.IdCategoria);
            if (IdCategoria == null)
            {
                return BadRequest("La categoria no existe");
            }

            var IdExperiencia = await _context.experiencias.FindAsync(experiencia.IdExperiencia);
            if (IdExperiencia != null)
            {
                return BadRequest("La experiencia existe");
            }
            _context.experiencias.Add(experiencia);
            await _context.SaveChangesAsync();
            return Ok("Experiencia registrada correctamente");
        }

        // DELETE: api/Experiencias/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteExperiencia(int id)
        {
            var experiencia = await _context.experiencias.FindAsync(id);
            if (experiencia == null)
            {
                return NotFound();
            }

            _context.experiencias.Remove(experiencia);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool ExperienciaExists(int id)
        {
            return _context.experiencias.Any(e => e.IdExperiencia == id);
        }
    }
}
