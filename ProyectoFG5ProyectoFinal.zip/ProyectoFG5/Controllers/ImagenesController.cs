﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ProyectoFG5.Data;
using ProyectoFG5.Models;

namespace ProyectoFG5.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ImagenesController : ControllerBase
    {
        private readonly BDConexion bDConexion;
        public ImagenesController(BDConexion bDConexion, IConfiguration configuration)
        {
            this.bDConexion = bDConexion;
        }
        [HttpPost("GuardarImagen")]
        public async Task<IActionResult> GuardarImagen([FromForm] Imagene archivo, [FromForm] int? experienciaId)
        {
            if (archivo == null || archivo.Archivo.Length == 0)
                return BadRequest("no se a enviado ningun archivo");
            var extensionesPermitidas = new[] { ".jpg", "jpeg", ".png", ".svg", ".avif" };
            var extension = Path.GetExtension(archivo.Archivo.FileName).ToLower();
            if (!extensionesPermitidas.Contains(extension))
                return BadRequest("tippo de archivo no permitido ");
            //subir archivo
            var nombreArchivo = $"{Guid.NewGuid()}{extension}";
            var carpetaDestino = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "Uploads", "Experiencias");
            Directory.CreateDirectory(carpetaDestino);

            var rutaFisica = Path.Combine(carpetaDestino, nombreArchivo);
            try
            {
                await using var stream = new FileStream(rutaFisica, FileMode.Create);
                await archivo.Archivo.CopyToAsync(stream);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"error al guardar el archivo: {ex.Message}");
            }
            var rutaWeb = Path.Combine("Uploads", "Productos", nombreArchivo).Replace("\\", "/");
            //guardar en la base de datos 
            var imagenDb = new Imagen
            {
                Ruta = rutaWeb,
                ExperienciaId = experienciaId,
            };
            bDConexion.Imagenes.Add(imagenDb);
            await bDConexion.SaveChangesAsync();

            return Ok(new { ruta = rutaWeb, id = imagenDb.Id });


        }
        public class Imagene
        {
            public IFormFile? Archivo { get; set; }
        }
    }
}
