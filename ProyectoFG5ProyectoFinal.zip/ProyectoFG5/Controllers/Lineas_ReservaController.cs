﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ProyectoFG5.Data;
using ProyectoFG5.Models;

namespace ProyectoFG5.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class Lineas_ReservaController : ControllerBase
    {
        private readonly BDConexion _context;

        public Lineas_ReservaController(BDConexion context)
        {
            _context = context;
        }

        // GET: api/Lineas_Reserva
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Lineas_Reserva>>> Getlineas_Reservas()
        {
            return await _context.lineas_Reservas.ToListAsync();
        }

        // GET: api/Lineas_Reserva/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Lineas_Reserva>> GetLineas_Reserva(int id)
        {
            var lineas_Reserva = await _context.lineas_Reservas.FindAsync(id);

            if (lineas_Reserva == null)
            {
                return NotFound();
            }

            return lineas_Reserva;
        }

        // PUT: api/Lineas_Reserva/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutLineas_Reserva(int id, Lineas_Reserva lineas_Reserva)
        {
            if (id != lineas_Reserva.IdLinea)
            {
                return BadRequest();
            }

            _context.Entry(lineas_Reserva).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!Lineas_ReservaExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Lineas_Reserva
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<Lineas_Reserva>> PostLineas_Reserva(Lineas_Reserva lineas_Reserva)
        {
            // Verificar si la línea ya existe
            var lineaExistente = await _context.lineas_Reservas.FindAsync(lineas_Reserva.IdLinea);
            if (lineaExistente != null)
            {
                return BadRequest("La linea_reserva ya existe");
            }

            // Para obtener el precio de la experiencia,
            var experiencia = await _context.experiencias.FindAsync(lineas_Reserva.IdExperiencia);
            if (experiencia == null)
            {
                return BadRequest("La experiencia no existe");
            }

            // Para calcular el subtotal de la línea 
            lineas_Reserva.Subtotal = lineas_Reserva.Cantidad * experiencia.Precio;

            // Para agregar la línea a la base de datos
            _context.lineas_Reservas.Add(lineas_Reserva);

            // Para guardar los cambios de la línea
            await _context.SaveChangesAsync();

            // Para actualizar el total de la reserva
            var reserva = await _context.reservas.FindAsync(lineas_Reserva.IdReserva);
            if (reserva != null)
            {
                // Sumar todos los subtotales de las líneas asociadas a esta reserva
                reserva.TotalReserva = await _context.lineas_Reservas
                    .Where(lr => lr.IdReserva == lineas_Reserva.IdReserva)
                    .SumAsync(lr => lr.Subtotal);

                await _context.SaveChangesAsync();
            }

            return Ok("La linea_reserva fue registrada correctamente y el total de la reserva fue actualizada");
        }



        // DELETE: api/Lineas_Reserva/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteLineas_Reserva(int id)
        {
            var lineas_Reserva = await _context.lineas_Reservas.FindAsync(id);
            if (lineas_Reserva == null)
            {
                return NotFound();
            }

            _context.lineas_Reservas.Remove(lineas_Reserva);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool Lineas_ReservaExists(int id)
        {
            return _context.lineas_Reservas.Any(e => e.IdLinea == id);
        }
    }
}
