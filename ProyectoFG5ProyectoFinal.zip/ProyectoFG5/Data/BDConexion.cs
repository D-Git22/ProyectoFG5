﻿using ProyectoFG5.Models;
using Microsoft.EntityFrameworkCore;

namespace ProyectoFG5.Data
{
    public class BDConexion : DbContext
    {
        public BDConexion(DbContextOptions options) : base(options) { }
        public DbSet<Categoria> categorias { get; set; }
        public DbSet<Cliente> clientes { get; set; }
        public DbSet<Experiencia> experiencias { get; set; }
        public DbSet<Itinerario> itinerarios { get; set; }
        public DbSet<ItinerarioExperiencia> itinerarioExperiencias { get; set; }
        public DbSet<Lineas_Reserva> lineas_Reservas { get; set; }
        public DbSet<Anfitrion> anfitriones { get; set; }
        public DbSet<Reseña> reseñas { get; set; }
        public DbSet<Reserva> reservas { get; set; }
        public DbSet<Imagen> Imagenes { get; set; }
        public DbSet<Usuario> usuarios { get; set; }
    }
}
