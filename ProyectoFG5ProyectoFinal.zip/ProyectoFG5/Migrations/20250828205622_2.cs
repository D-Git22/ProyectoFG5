﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ProyectoFG5.Migrations
{
    /// <inheritdoc />
    public partial class _2 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Imagenes_experiencias_IdExperiencia",
                table: "Imagenes");

            migrationBuilder.RenameColumn(
                name: "IdExperiencia",
                table: "Imagenes",
                newName: "ExperienciaId");

            migrationBuilder.RenameIndex(
                name: "IX_Imagenes_IdExperiencia",
                table: "Imagenes",
                newName: "IX_Imagenes_ExperienciaId");

            migrationBuilder.AddForeignKey(
                name: "FK_Imagenes_experiencias_ExperienciaId",
                table: "Imagenes",
                column: "ExperienciaId",
                principalTable: "experiencias",
                principalColumn: "IdExperiencia");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Imagenes_experiencias_ExperienciaId",
                table: "Imagenes");

            migrationBuilder.RenameColumn(
                name: "ExperienciaId",
                table: "Imagenes",
                newName: "IdExperiencia");

            migrationBuilder.RenameIndex(
                name: "IX_Imagenes_ExperienciaId",
                table: "Imagenes",
                newName: "IX_Imagenes_IdExperiencia");

            migrationBuilder.AddForeignKey(
                name: "FK_Imagenes_experiencias_IdExperiencia",
                table: "Imagenes",
                column: "IdExperiencia",
                principalTable: "experiencias",
                principalColumn: "IdExperiencia");
        }
    }
}
