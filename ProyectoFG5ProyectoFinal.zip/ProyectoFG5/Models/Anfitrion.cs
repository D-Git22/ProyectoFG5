﻿using System.ComponentModel.DataAnnotations;

namespace ProyectoFG5.Models
{
    public class Anfitrion
    {
        [Key]
        public int IdAnfitrion { get; set; }

        [Required(ErrorMessage = "El nombre es requerido")]
        [StringLength(50, MinimumLength = 3)]
        public string? Nombre { get; set; }

        [Required]
        [StringLength(50, MinimumLength = 3)]
        public string? Email { get; set; }
    }
}