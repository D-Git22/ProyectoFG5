﻿using System.ComponentModel.DataAnnotations;

namespace ProyectoFG5.Models
{
    public class Categoria
    {
        [Key]
        public int IdCategoria { get; set; }

        [Required(ErrorMessage = "El nombre es requerido")]
        [StringLength(50, MinimumLength = 3)]
        public string? Nombre { get; set; }
    }
}