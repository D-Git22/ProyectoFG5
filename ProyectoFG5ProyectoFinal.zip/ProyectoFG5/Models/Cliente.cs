﻿using System.ComponentModel.DataAnnotations;

namespace ProyectoFG5.Models
{
    public class Cliente
    {
        [Key]
        public int IdCliente { get; set; }

        [Required(ErrorMessage = "El nombre es requerido")]
        [StringLength(50, MinimumLength = 3)]
        public string? Nombre { get; set; }

        [Required]
        [StringLength(50, MinimumLength = 3)]
        public string? Email { get; set; }
    }
}