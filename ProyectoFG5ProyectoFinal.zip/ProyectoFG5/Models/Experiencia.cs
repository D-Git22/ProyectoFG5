﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ProyectoFG5.Models
{
    public class Experiencia
    {
        [Key]
        public int IdExperiencia { get; set; }

        [Required(ErrorMessage = "El nombre es requerido")]
        [StringLength(50, MinimumLength = 3)]

        public string? Nombre { get; set; }

        [Column(TypeName = "decimal(8,2)")]
        [Range(0, double.MaxValue)]
        public decimal Precio { get; set; }

        [Range(0, int.MaxValue)]
        public int Cupos { get; set; } = 0;

        public int IdCategoria { get; set; }
        [ForeignKey(nameof(IdCategoria))]
        public Categoria? categoría { get; set; }

        public int IdAnfitrion { get; set; }
        [ForeignKey(nameof(IdAnfitrion))]
        public Anfitrion? anfitrion { get; set; }
    }
}
