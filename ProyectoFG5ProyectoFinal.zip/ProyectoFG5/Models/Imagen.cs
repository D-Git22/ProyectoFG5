﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ProyectoFG5.Models
{
    public class Imagen
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public string? Ruta { get; set; } //ruta de la imagen en wwwroot
        public int? ExperienciaId { get; set; }
        [ForeignKey(nameof(ExperienciaId))]
        public Experiencia? experiencia { get; set; } //si usas relacion con EF
    }
}
