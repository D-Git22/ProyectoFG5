﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ProyectoFG5.Models
{
    //Una vez ingresado el id de la reserva y la experiencia, y cuantas veces
    //realiza dicha experiencia, al subtotal, no hay necesidad de ingresar nada, porque se
    //calculara con: subtotal = precio_experiencia * cantidad
    public class Lineas_Reserva
    {
        [Key]
        public int IdLinea { get; set; }

        public int IdReserva { get; set; }
        [ForeignKey(nameof(IdReserva))]
        public Reserva? reserva { get; set; }

        public int IdExperiencia { get; set; }
        [ForeignKey(nameof(IdExperiencia))]
        public Experiencia? experiencia { get; set; }

        [Required]
        [Range(1, int.MaxValue)]
        public int Cantidad { get; set; }

        [Required]
        [Column(TypeName = "decimal(10,2)")]
        [Range(0, double.MaxValue)]
        public decimal Subtotal { get; set; }
    }
}
