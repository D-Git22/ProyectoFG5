﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ProyectoFG5.Models
{
    public class Reserva
    {
        [Key]
        public int IdReserva { get; set; }


        public int IdCliente { get; set; }
        [ForeignKey(nameof(IdCliente))]
        public Cliente? cliente { get; set; }

        [Required(ErrorMessage = "la fecha es obligatoria")]
        [DataType(DataType.Date)]
        public DateTime? FechaReserva { get; set; }

        //El TotalReserva se calcula sumando todos los subtotales en líneas de esa reserva.
        [Required]
        [Column(TypeName = "decimal(10,2)")]
        [Range(0, double.MaxValue)]
        public decimal TotalReserva { get; set; } = 0;
    }
}
