using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ProyectoFG5.Models;

namespace SFrontend.Pages.Itinerarios
{
    public class CreateItinerarioModel : PageModel
    {
        private readonly HttpClient _httpClient;
        public CreateItinerarioModel(IHttpClientFactory httpClientFactory)
        {
            _httpClient = httpClientFactory.CreateClient("API");
        }

        [BindProperty]
        public Itinerario itinerarios { get; set; }
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }
            var response = await _httpClient.PostAsJsonAsync("api/Itinerarios", itinerarios);
            if (response.IsSuccessStatusCode)
            {
                return RedirectToPage("Index");
            }
            ModelState.AddModelError(string.Empty, "Error al guardar los datos");
            return Page();

        }
    }
}
