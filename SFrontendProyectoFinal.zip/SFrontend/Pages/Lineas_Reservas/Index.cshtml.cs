using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ProyectoFG5.Models;
using System.Net;
using System.Net.Sockets;

namespace SFrontend.Pages.Lineas_Reservas
{
    public class IndexModel : PageModel
    {
        private readonly HttpClient _httpClient;
        //
        public List<Lineas_Reserva> Lineas_Reserva { get; set; } = new();
        public IndexModel(IHttpClientFactory httpClientFactory)
        {
            _httpClient = httpClientFactory.CreateClient("API");
        }
        public async Task<IActionResult> OnGetAsync()
        {
            try
            {
                //
                var response = await _httpClient.GetAsync("api/Lineas_Reserva");
                if (response.IsSuccessStatusCode)
                {
                    Lineas_Reserva = await response.Content.ReadFromJsonAsync<List<Lineas_Reserva>>();
                    return Page();
                }
                if (response.StatusCode == HttpStatusCode.NotFound)
                {
                    return NotFound();
                }
                return StatusCode((int)response.StatusCode);
            }
            catch (HttpRequestException ex) when (ex.InnerException is SocketException)
            {
                ModelState.AddModelError(string.Empty, "El servicio Api no esta disponible ");
                return Page();
            }
            catch (Exception)
            {
                ModelState.AddModelError(string.Empty, "ocurrio un error al cargar");
                return Page();
            }
        }
    }
}
