﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;

namespace SFrontend.Pages.Usuarios
{
    public class LoginRegisterModel : PageModel
    {
        private readonly IHttpClientFactory _httpClientFactory;
        public string Mensaje { get; set; } = "";

        public LoginRegisterModel(IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
        }

        [BindProperty]
        public string Email { get; set; }
        [BindProperty]
        public string Password { get; set; }

        public void OnGet()
        {
        }

        //  Login
        public async Task<IActionResult> OnPostLogin()
        {
            var cliente = _httpClientFactory.CreateClient("API");

            var datos = new { Email, Password };
            var contenido = new StringContent(JsonSerializer.Serialize(datos), Encoding.UTF8, "application/json");

            var response = await cliente.PostAsync("api/Auth/login", contenido);

            if (response.IsSuccessStatusCode)
            {
                var json = await response.Content.ReadAsStringAsync();

                // Leer JSON con token
                using var doc = JsonDocument.Parse(json);
                var token = doc.RootElement.GetProperty("token").GetString();

                //  Guardar token en sesión
                HttpContext.Session.SetString("JwtToken", token);

                // Redirigir a Privacy (usa Layout)
                return Redirect("/Privacy");

            }
            else
            {
                Mensaje = "❌ Credenciales inválidas";
                return Page();
            }
        }

        //  Registro
        public async Task<IActionResult> OnPostRegister()
        {
            var cliente = _httpClientFactory.CreateClient("API");

            var datos = new { Email, Password };
            var contenido = new StringContent(JsonSerializer.Serialize(datos), Encoding.UTF8, "application/json");

            var response = await cliente.PostAsync("api/Auth/register", contenido);

            if (response.IsSuccessStatusCode)
            {
                Mensaje = "✅ Usuario registrado correctamente. Ahora puedes iniciar sesión.";
            }
            else
            {
                Mensaje = "❌ Error: el email ya existe o datos inválidos.";
            }

            return Page();
        }
    }
}
