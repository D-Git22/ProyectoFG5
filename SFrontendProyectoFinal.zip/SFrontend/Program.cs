using System.Net.Http.Headers;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddRazorPages();

builder.Services.AddHttpContextAccessor();


// HttpClient para la API
builder.Services.AddHttpClient("API", client =>
{
    client.BaseAddress = new Uri("https://localhost:7146/");
    client.DefaultRequestHeaders.Accept.Add(
        new MediaTypeWithQualityHeaderValue("application/json"));
});

//  Activar cache distribuida y sesiones
builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(30); // expira en 30 min
    options.Cookie.HttpOnly = true;  // seguridad
    options.Cookie.IsEssential = true;
});

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

//  Habilitar sesiones aqu�
app.UseSession();

app.UseAuthorization();



//  Redirigir al login como p�gina inicial
app.MapGet("/", context =>
{
    context.Response.Redirect("/Usuarios/LoginRegister");
    return Task.CompletedTask;
});

app.MapRazorPages();

app.Run();
